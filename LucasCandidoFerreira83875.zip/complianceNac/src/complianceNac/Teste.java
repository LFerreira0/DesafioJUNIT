package complianceNac;

import org.junit.Assert;
import org.junit.Test;

public class Teste {

	@Test
	public void test() {
		Resposta respostaPrisioneiroA = Resposta.DELACAO;
		Resposta respostaPrisioneiroB = Resposta.DELACAO;
		
		Primeira questao1 = new Primeira();
		Assert.assertNotNull(questao1);
		
		int penapreso1 = questao1.calculaPena(respostaPrisioneiroA, respostaPrisioneiroB);
		int penapreso2 = questao1.calculaPena(respostaPrisioneiroA, respostaPrisioneiroB);
		
		
	}

}
