package complianceNac;

import org.junit.Test;

public class Teste {

	@Test
	public void test() {
		Resposta respostaSuspeitoA = Resposta.DELACAO;
		Resposta respostaSuspeitoB = Resposta.DELACAO;
		
		
	}

}
