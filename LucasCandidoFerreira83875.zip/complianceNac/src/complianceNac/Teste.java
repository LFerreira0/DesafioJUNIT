package complianceNac;

import org.junit.Test;

public class Teste {

	@Test
	public void test() {
		Resposta respostaPrisioneiroA = Resposta.DELACAO;
		Resposta respostaPrisioneiroB = Resposta.DELACAO;
		
		
	}

}
