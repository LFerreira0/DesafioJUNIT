package complianceNac;

public enum Resposta {
	
	DELACAO, NEGACAO
}
