package complianceNac;

public class Primeira {

		   int PENA_INOCENCIA = 0;
		   int PENA_CONDENACAO_MUTUA = 5;
		   int PENA_CONDENACAO_INDIVIDUAL = 10;
		   int PENA_CONDENACAO_CUMPLICES = 1;

		   int calculaPena(String respostaPrisioneiroA, String respostaPrisioneiroB) {
			   
		      if (respostaPrisioneiroA = "dasds") {
		          if (respostaPrisioneiroB = "dasdasd") {
		            return PENA_CONDENACAO_MUTUA;
		          } else {
		                 return PENA_CONDENACAO_INDIVIDUAL;
		                 }
		       } else {
		                if (respostaPrisioneiroB = �Culpado�) {
		                    return PENA_CONDENACAO_CUMPLICES;
		                } else {
		                         return PENA_INOCENCIA;
		                        }
		                }
		     }
		}

	

